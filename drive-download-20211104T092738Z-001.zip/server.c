#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h> 
#include <arpa/inet.h>

#define SERV_PORT 1255
#define MAXLINE 255

#define MAX_CNN 10

int sockfd, n;
socklen_t len;
char mesg[MAXLINE]; 
struct sockaddr_in servaddr, cliaddr;
socklen_t addrlen = sizeof(cliaddr);

int userTotal = 0;
char account[30];


typedef struct{
    char name[10];
    char password[10];
    int tt;
    int checkLogin;
}Sv;

Sv *sv = NULL;

int readFile() {
    FILE *file = NULL;

    file = fopen("user.txt", "r");

    if (file == NULL) return -1;

    while (!feof(file)) {
        if (userTotal == 0) sv = (Sv *) calloc(1, sizeof(Sv));
        else
            sv = (Sv *) realloc(sv,(userTotal + 1) * sizeof(Sv));
        fscanf(file, "%s", sv[userTotal].name);
        fscanf(file, "%s", sv[userTotal].password);
        fscanf(file, "%d", &sv[userTotal].tt);
        fscanf(file, "%d", &sv[userTotal].checkLogin);
        userTotal++;
        }
    fclose(file);
    return 0;
}

void freeData() {
    free(sv);
}

int checkLogin(char * name){
    int i;
    for(i = 0; i < userTotal ; i++){
        if(strcmp(name,sv[i].name) == 0){
            return 1;
        }
    }

    return 0;
}

int setPasswordInFile(){
    FILE *file = NULL;
    int n = 0;
    file = fopen("user.txt", "w");

    if (file == NULL) return -1;

    while (n < userTotal) {
        if(n == userTotal - 1) fprintf(file, "%s %s %d %d", sv[n].name,sv[n].password,sv[n].tt,sv[n].checkLogin);
        else fprintf(file, "%s %s %d %d\n", sv[n].name,sv[n].password,sv[n].tt,sv[n].checkLogin);
        n++;  
    }
    fclose(file);
    return 0;
}

int checkPassword(char * name,char * password){
    int i;
    for(i = 0; i < userTotal ; i++){
        if(strcmp(name,sv[i].name) == 0){
            if(sv[i].tt == 1){
                if(strcmp(password,sv[i].password) == 0){
                    return 1;
                }else{
                    sv[i].checkLogin += 1;
                    if(sv[i].checkLogin >= 3){
                        sv[i].tt = 2;
                    }
                    setPasswordInFile();
                }
            }else{
                return -1;
            }
        }
    }

    return 0;
}

int changePassword(char *name,char* newPassword){
    int i;
    for(i = 0; i < userTotal ; i++){
        if(strcmp(name,sv[i].name) == 0){
            strcpy(sv[i].password,newPassword);
            setPasswordInFile();
            return 1;
        }
    }  

    return 0;
}

int checkChar(char * mess){
    int i,check;
    char so[10] = {0};
    char chu[10] = {0};
    char kytudacbiet[10] = {0};
    char noichuoi[20] = {0};
    int j=0,k=0,m=0;
    for(i = 0; i < strlen(mess); i++){
        check = mess[i] - '0';
        if((check >= 0 && check <= 9)){
            so[j] = mess[i];
            j++;
        }else if((check >= 49 && check <= 74) || (check >= 17 && check <= 42)){
            chu[k] = mess[i];
            k++;
        }else{
            kytudacbiet[m] = mess[i];
            m++;
        }
    } 


    if(m == 0){
        strcat(noichuoi,so);
        strcat(noichuoi," ");
        strcat(noichuoi,chu);
        sendto(sockfd, noichuoi, 100, 0, (struct sockaddr *) &cliaddr, len);
        return 1;
    }else{
        sendto(sockfd, "Chua ky tu dac biet", 100, 0, (struct sockaddr *) &cliaddr, len);
        return 0;
    }
}

int main(int argc, char* argv[])
{    
    sockfd = socket(AF_INET, SOCK_DGRAM, 0); 
    bzero(&servaddr, sizeof(servaddr)); 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(atoi(argv[1])); 
    if (bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))>=0)
    {
        printf("Server is running at port %d\n", atoi(argv[1]));
    }
    else
    {
        perror("bind failed");
        return 0;
    }

    readFile();

    for ( ; ; ) { 
        char name[10] = {0};
        char password[10] = {0};
        len = sizeof(cliaddr); 
        printf("Receiving data ...");
        n = recvfrom(sockfd, name, 10, 0, (struct sockaddr *) &cliaddr, &len); 
        puts(name);
        if(checkLogin(name) == 1){
            sendto(sockfd, "oke", 10, 0, (struct sockaddr *) &cliaddr, len); 
            while (1)
            {
                printf("Receiving data ...");
                n = recvfrom(sockfd, password, MAXLINE, 0, (struct sockaddr *) &cliaddr, &len); 
                password[n] = 0;
                puts(password);
                int a = checkPassword(name,password);
                if(a == 1){
                    sendto(sockfd, "1", 100, 0, (struct sockaddr *) &cliaddr, len); 
                    while(1){
                        printf("Receiving data ...");
                        n = recvfrom(sockfd, mesg, MAXLINE, 0, (struct sockaddr *) &cliaddr, &len); 
                        mesg[n] = 0;
                        puts(mesg);
                        if(strcmp(mesg,"bye") == 0){
                            sendto(sockfd, "out", 100, 0, (struct sockaddr *) &cliaddr, len); 
                            break;
                        }else{
                            sendto(sockfd, "oke", 100, 0, (struct sockaddr *) &cliaddr, len); 
                            printf("Receiving data ...");
                            n = recvfrom(sockfd, mesg, MAXLINE, 0, (struct sockaddr *) &cliaddr, &len); 
                            mesg[n] = 0;
                            puts(mesg);

                            if(checkChar(mesg) == 1){
                                changePassword(name,mesg);
                            }
                        }
                    }
                    break;
                }else if(a == 0){
                    sendto(sockfd, "0", 100, 0, (struct sockaddr *) &cliaddr, len); 
                }else{
                    sendto(sockfd, "-1", 100, 0, (struct sockaddr *) &cliaddr, len);
                }
            }          
        }else{
            sendto(sockfd, "Dang nhap that bai", 100, 0, (struct sockaddr *) &cliaddr, len); 
        }
    }

    freeData();
    close(sockfd);
    
}
