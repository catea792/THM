#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> 
#include <stdbool.h>

#define MAXLINE 250

void login(char * name){
    printf("Nhap ten : ");
    gets(name);
}

void inputPassword(char * password){
    printf("Nhap mat khau : ");
    gets(password);
}

int main(int argc, char* argv[])
{
    int sockfd, n, from_len;
    struct sockaddr_in servaddr, from_socket;
    socklen_t addrlen = sizeof(from_socket);
    char sendline[MAXLINE], recvline[MAXLINE + 1];
    FILE *fp;

    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(atoi(argv[2])); 
    servaddr.sin_addr.s_addr=inet_addr(argv[1]);
    //inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr); 

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    printf("creat socket\n");

    while (1) { 
        char name[10];
        char matkhau[10];
        bool check = false;
        login(name);
        sendto(sockfd, name, strlen(name), 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
        n = recvfrom(sockfd, recvline, MAXLINE, 0,  (struct sockaddr *) &from_socket, &addrlen);
        recvline[n] = 0; //null terminate  
        printf("From Server: %s\n",recvline);
        if(strcmp(recvline,"oke") == 0){
            check = true;
            while (check)
            {
                inputPassword(matkhau);
                sendto(sockfd, matkhau, strlen(matkhau), 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
                n = recvfrom(sockfd, recvline, MAXLINE, 0,  (struct sockaddr *) &from_socket, &addrlen);
                recvline[n] = 0; //null terminate  
                printf("From Server: %s\n",recvline);

                if(strcmp(recvline,"1") == 0){
                    printf("dang nhap thanh cong\n");
                    while (1)
                    {
                        char mess[MAXLINE];
                        printf("Client : "); gets(mess);
                        if(strcmp(mess,"bye") == 0){
                            sendto(sockfd, "bye", 100, 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
                            n = recvfrom(sockfd, recvline, MAXLINE, 0,  (struct sockaddr *) &from_socket, &addrlen);
                            recvline[n] = 0; //null terminate  
                            printf("From Server: %s\n",recvline);
                            break;
                        }else if(strcmp(mess,"change") == 0){
                            char newPassword[10];
                            sendto(sockfd, "change", 100, 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
                            n = recvfrom(sockfd, recvline, MAXLINE, 0,  (struct sockaddr *) &from_socket, &addrlen);
                            recvline[n] = 0; //null terminate  
                            printf("From Server: %s\n",recvline);
                            printf("Nhap password moi : "); gets(newPassword);
                            sendto(sockfd,newPassword, strlen(newPassword), 0, (struct sockaddr *) &servaddr, sizeof(servaddr));
                            n = recvfrom(sockfd, recvline, MAXLINE, 0,  (struct sockaddr *) &from_socket, &addrlen);
                            recvline[n] = 0; //null terminate  
                            printf("From Server: %s\n",recvline);
                        }else{
                            continue;
                        }
                    }                  
                    
                    check = false;
                }else if(strcmp(recvline,"0") == 0){
                    printf("sai mat khau\n");
                }else{
                    printf("tai khoan da bi khoa\n");
                }
            }     
        }
    } 
}
