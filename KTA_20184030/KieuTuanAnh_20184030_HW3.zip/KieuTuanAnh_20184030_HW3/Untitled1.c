#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h> 
#include <stdbool.h> 
#include <netinet/in.h> 
#include <netdb.h>
#include <arpa/inet.h>
#include <ctype.h>

typedef struct node {
  	char username[25];
	char password[25];
	char homepage[25];
	
	int status;
	struct node *next;
}node;

node *head = NULL;
node *curr = NULL;


void take_IP(char *s,struct hostent *host_name){
    struct in_addr **AliasIP;   
    host_name = gethostbyname(s);
    if(host_name == NULL) { 
        printf("Khong co thong tin \n\n"); 
    }else{
        printf("Official address: %s\n", inet_ntoa(*(struct in_addr*)host_name->h_addr));
        printf("Alias IP: \n");
        AliasIP = (struct in_addr **)host_name->h_addr_list;
        for(int i = 0; AliasIP[i] != NULL; i++) {
            printf("%s\n", inet_ntoa(*AliasIP[i]));
        }
        printf("\n");
    }
             
}
void take_Domain(char* s, struct in_addr addr){
    struct hostent *host_name; 
    inet_aton(s, &addr);
    host_name = gethostbyaddr(&addr, sizeof(addr), AF_INET);
    if (host_name == NULL) { 
        printf("Khong co thong tin ERROR\n\n"); 
        
    }else{
        printf("Host name: %s\n", host_name->h_name);
        printf("Alias name: \n");
        if (host_name->h_aliases[0] == NULL)
        {
            printf("NULL\n\n");
        }
        else
        {
            for (int i = 0; host_name->h_aliases[i] != NULL; i++){
                printf("\t%s\n", host_name->h_aliases[i]);
            }
        }
    }
}







void insert(char username[25], char password[25], int status, char homepage[25]){
	node *temp;
	temp=(node *)malloc(sizeof(node));
	strcpy(temp->username, username);
	strcpy(temp->password, password);
	strcpy(temp->homepage, homepage);
	temp->status = status;
	temp->next = head;
	head = temp;
}

node *find(char name[20]){

   
   node *curr = head;

  
   if(head == NULL)
	{
      return NULL;
    }

   while(strcmp(curr->username, name) != 0){
      if(curr->next == NULL){
         return NULL;
      }else {
         curr = curr->next;
      }
   }      
   return curr;
}
void update_passwd (char a[],char b[],char c[]){

    int pos = 0;
   
   if(head==NULL) {
      printf("Error!");
      return;
   } 

   curr = head;
   while(curr->next!=NULL) {
      if(strcmp(curr->username,a)==0) {
        strcpy(curr->password,c);
        printf("password changed!\n");
         return;
      }
      curr = curr->next;
      pos++;
   }
   printf(" khong ton tai trong list\n");
	
	
}

void update_data(char b[]) {
   int pos = 0;
   
   
   if(head==NULL) {
      printf("Danh sach lien ket chua duoc khoi tao");
      return;
   } 

   curr = head;
   while(curr->next!=NULL) {
      if(strcmp(curr->username,b)==0) {
         curr->status = 1;
         printf("\nTim thay  tai vi tri %d\n", pos);
         writeFile();
         return;
      }
      curr = curr->next;
      pos++;
   }
   printf("%d khong ton tai trong list\n");
}


void printFile()
{
    node *temp;
    temp = head;
    printf("-------------LIST ACCOUNT------------\n");
    while(temp)
    {
    	
    	printf("%25s %25s %d %25s",temp->username, temp->password, temp->status, temp->homepage);
        printf("\n");
        temp=temp->next;
    }
    printf("\n");
}

void openFile(){
	node *acc;
	char *username;
	char *password;
	char *homepage;
	int status;
	char c;
	int u = 0, p = 0, blank = 0;
	username = (char *)malloc(25);
	password = (char *)malloc(25);
	homepage = (char *)malloc(25);
    FILE *fptr;
	if((fptr=fopen("nguoidung.txt","r+"))==NULL){
		printf("Khong tim thay %s\n","nguoidung.txt");
		return;
	}
	while(1){
		fscanf(fptr,"%s",username);
		fscanf(fptr,"%s",password);
		fscanf(fptr,"%d",&status);
		fscanf(fptr,"%s",homepage);
		if(feof(fptr)) break;
		insert(username, password, status, homepage);
	}
	free(username); free(password); free(homepage);
	fclose(fptr);
}

void writeFile(){
	FILE *fptr;
	node *temp;
    temp = head;
    fptr=fopen("nguoidung.txt","w+");
    while(temp){
    	fprintf(fptr, "%s %s %d %s", temp->username, temp->password, temp->status, temp->homepage);
    	fprintf(fptr, "\n");
    	temp=temp->next;
    }
    fclose(fptr);
}

void registerAccount(){
	char username[25];
	char password[25];
	char homepage[25];
	//__fpurge(stdin);
	printf("---------Register\n");
	printf("Username: "); scanf("%s", username);
	printf("\n");
	printf("Password: "); scanf("%s", password);
	printf("\n");
	printf("Homepage: "); scanf("%s", homepage);
	printf("\n");
	if(find(username) != NULL){
	printf("Account already exists!");	
	} 
	else{
		insert(username, password, 2, homepage);
		printf("successfull registration!\n");
		writeFile();
		printFile();
	}
	printf("\n");
}

void activeAccount(){
	int count_code =0;
	char username[25];
	char password[25];
	char code[20] ;
	char i[] = "20184030";
	printf("---------Active\n");
    int code_count =0;
    printf("Username: "); scanf("%s", username);
	printf("\n");
    printf("Password: "); scanf("%s", password);
	printf("\n");
	node *acc = find(username);
	if(acc != NULL){
		
	    do{
		printf("Code: "); scanf("%s", code);
		printf("\n");
		if((strcmp(acc->password,password) == 0) && strcmp(code,i) == 0){
		
                        update_data(username);
		        writeFile();
		        printf("account has been active \n");
		        return acc;
}
		else {
			printf("Wrong code,account is not actived\n");
			code_count++;
			
			}
		}while(code_count < 4);
		if(code_count == 4) {
			printf("The account has been locked\n");
			acc->status = 0;
			writeFile();
			return NULL;
		}
	}
	else{
		printf("Account does not exist\n");
		return NULL; 
	} 
}
node *signin(){
	char username[20];
	char password[20];
	int login_count = 0;
	printf("---------Sign In\n");
	printf("Username: "); scanf("%s", username);
	printf("\n");
	node *acc = find(username);
	if(acc != NULL){
		if(acc->status == 0){
			printf("Account has been blocked!\n");
			return NULL;
		}
		do{
		printf("Password: "); scanf("%s", password);
		printf("\n");
		if(strcmp(acc->password,password) == 0){
			printf("Success\n");
			return acc; 
			}
		else {
			printf("Wrong Password\n");
			login_count++;
			
			}
		}while(login_count < 3);
		if(login_count == 3) {
			printf("The account has been locked\n");
			acc->status = 0;
			writeFile();
			return NULL;
		}
	}
	else{
		printf("Account does not exist\n");
		return NULL; 
	} 
}

void search(){
	char username[25];
	printf("---------Search\n");
	printf("Username: "); scanf("%s", username);
	printf("\n");
	node *acc = find(username);
	if(acc != NULL){
		printf("Username: %25s Status: %d\n", acc->username, acc->status);
	}
	else printf("Account does not exist\n");
}

node *signout(){
	char username[20];
	printf("---Sign Out\n");
	printf("Username: "); scanf("%s", username);
	printf("\n");
	node *acc = find(username);
	if(acc == NULL){
		printf("Account not exist\n");
		return NULL;
	}
	else return acc;
}

int choice(){
	int c = 0;
	printf("USER MANAGEMENT PROGRAM\n");
	printf("-----------------------------------\n");
	printf("1. Register\n");
	printf("2. ActiveAccount\n");
	printf("3. Sign in\n");
	printf("4. Search\n");
	printf("5. Change Password\n");
	printf("6. Sign out\n");
	printf("7. Homepage with IP\n");
	printf("8. Homepage with domain\n");
	printf("Your choice (1-8, other to quit):\n"); scanf("%d", &c);
	return c;	
}

int main()
{
	openFile();
	printFile();
	struct hostent *host_name;
    struct in_addr **AliasIP;
    struct in_addr addr;
    char a[20];
    char b[20];
    char c[20];
	char d[20];
	int ch;
	
	node *login_account = NULL;
	node *signout_account = NULL;
	do{
		ch = choice();
		
		switch(ch){
		case 1: registerAccount(); break;
		case 2 : activeAccount(); printFile();
			
			break;
		case 3: login_account = signin(); break;
		case 4: {
			if(login_account != NULL) {
				
				search();
			}
			else printf("Sign in first!\n");
		} break;
		case 5 : 
		if(login_account == NULL) printf("Sign in first!\n"); 
		else{
		
	    
	    printf("---------Changepasswd\n");
	    printf("Username: "); scanf("%s", a);
	    printf("\n");
	    printf("Password: "); scanf("%s", b);
	    printf("\n");
	    
	    printf("New Password: "); scanf("%s", c); 
	    node *acc = find(a);
		//update_passwd (a,b,c);
		if(strcmp(acc->password,b) == 0){
		update_passwd(a,b,c);
		writeFile();
        
				
	} 
	else{
		printf("Current password is incorrec!");
	        printf("\n");
                }
		printFile();} break;
		case 6: {
			if(login_account == NULL) printf("Sign in first!\n"); 
			else{
				signout_account = signout();
				if(signout_account)
				if(strcmp(signout_account->username,login_account->username) == 0){
					printf("Gudbike Hust\n");
					login_account = NULL;
				}
				else printf("Wrong Username!\n");
			}			
		} break;
		case 7: {
			if(login_account == NULL){ printf("Sign in first!\n");}
			else if(login_account != NULL){
				take_Domain(login_account->homepage,addr);
			}
			else {printf("Wrong parameter\n\n");}
			
			


		}break;
		case 8: {
			if(login_account == NULL) {printf("Sign in first!\n");}
			else if(login_account != NULL){
				take_IP(login_account->homepage,host_name);
			}
			else {printf("Wrong parameter\n\n");}

		}break;
		
		
		
	}
	}
	while(ch > 0 && ch < 9);
	

	return 0;
}
