#ifndef PRINT_H
#define PRINT_H

void print_spin_result(int spin_code);
void welcome();
void menu_login();
 #endif
