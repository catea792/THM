#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h>
#include<stdlib.h> 
int STT = 0;
char USERNAME[20];
char PASSWORD[20];
#define DONE "DONE"
#define ERROR "error"
#define BLOCKED "Blocked"

void savingLogin(char node_name[20], char node_password[20]){
	int k=0; int h=0;
	for (k=0; k< strlen(node_name); k++){
		USERNAME[k] = node_name[k];
	}
	for (h=0; h< strlen(node_password); h++){
		PASSWORD[h] = node_password[h];
	}
	STT = 1;
}
int main(int argc, char *argv[])
{
	if(argc!=3){
		printf("Please input IP address and port number\n");
		return 0;
	}
	char *ip_address = argv[1];
	int PORT = atoi(argv[2]);
	struct sockaddr_in serv_addr; 
	int sock = 0;
	char buffer[1000] = {0};

	
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 

	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr = inet_addr(ip_address); 
	
	
	if(inet_pton(AF_INET, ip_address, &serv_addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 

	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
	{ 
		printf("\nConnection Failed \n"); 
		return -1; 
	}
	while(1){
		printf("---------------------------------------\n");
		printf("1. Log in\n");
		printf("2. Log out\n");
		printf("3. Quit\n");
		printf("Your choice : ");
		char choice;
		scanf("%s", &choice);
		
			if (choice == '1'){
				if (STT == 1 ){
					printf("You have already log in\n");
				}
				if(STT == 2){
					printf("This window can not log in more.\n");
				}
				if(STT == 0){
					while ((getchar()) != '\n');
					char asign[1000] = {0};
					char node_name[20], node_password[20];
					printf("Username:");
					scanf("%s", node_name);
					send(sock, node_name, strlen(node_name), 0);
					recv(sock, asign, sizeof(asign), 0);
					if (strcmp(asign,DONE)==0) { 
						while ((getchar()) != '\n');
						printf("Password: ");
						scanf("%s", node_password);
						send(sock, node_password, strlen(node_password), 0);
						char asign[1000] = {0};
						recv(sock, asign, sizeof(asign), 0);
						if (strcmp(asign, DONE)==0){
							printf("Log in SUCCESSFULLfully\n");
							savingLogin(node_name,node_password);
						}
						if (strcmp(asign, ERROR)==0)
						{
							while ((getchar()) != '\n');
							printf("Password incorrect please try again\nPassword: ");
							scanf("%s", node_password);
							send(sock, node_password, strlen(node_password), 0);
							char asign[1000] = {0};
							recv(sock, asign, sizeof(asign), 0);
							if (strcmp(asign, DONE)==0){
								printf("Log in SUCCESSFULLfully\n");
								savingLogin(node_name,node_password);
							}
							if (strcmp(asign, ERROR)==0){
								while ((getchar()) != '\n');
								printf("Password incorrect please try again\nPassword: ");
								scanf("%s", node_password);
								send(sock, node_password, strlen(node_password), 0);
								char asign[1000] = {0};
								recv(sock, asign, sizeof(asign), 0);
								if (strcmp(asign, DONE)==0){
									printf("Log in SUCCESSFULLfully\n");
									savingLogin(node_name,node_password);
								}
								if (strcmp(asign, ERROR)==0){
									printf("Password in correct 3 times. Block account\n");
								}
							}
						}
					}
					if (strcmp(asign,ERROR)==0){
						printf("tai khoan khong ton tai\n");
					}
					if (strcmp(asign,BLOCKED)==0)	{
						printf("Account is blocked, can't log in\n");
					}			
				}
				
			}
		
			else if (choice == '2'){
				if (STT == 0){
					printf("Haven't sign in please log in first\n");
				}
				if (STT == 2){
					printf("Have already log out\n");
				}
				if (STT == 1){
					printf("Sign out username %s successfully\n", USERNAME);
					STT = 2;
				}				
				
			}
			
			else if (choice == '3'){
				return 0;
			}
	
			else{
				printf("WRONG INPUT, CHOOSE AGAIN!\n");
			}
		}
	
	
	return 0;
}