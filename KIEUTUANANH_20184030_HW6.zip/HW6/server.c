#include<stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <errno.h>
#include <arpa/inet.h>

#define DONE "done"
#define ERROR "error"
#define BLOCKED "Blocked"
typedef struct 
{
	char uname[20];
	char pword[20];
	int stt;
}elementtype;

#include "linkedlist.h"

void sig_chld(int signo){
	pid_t pid;
	int stat;
	pid = waitpid(-1, &stat, WNOHANG);
	printf("child %d terminated\n", pid );
}
int searchData(singleList list, char username[30])  {  
    list.cur = list.root; 
   
    while (list.cur != NULL)  
    {  
        if (strcmp(list.cur->tree.uname, username) == 0)  
            return 1;  
        list.cur = list.cur->next;
    }  
    return 0;  
} 
void getDatatoList(singleList *list,elementtype tree){
	
	deleteSingleList(list);
	FILE *fp;
	fp = fopen("account.txt","r");

	char c;
	int count =0;
	for (c = getc(fp); c != EOF; c = getc(fp)) 
	{
        if (c == '\n') 
            count = count + 1; 
	}
	fclose(fp);
	
	fp = fopen("account.txt","r");
	for(int i=0;i< count + 1;i++){
		fscanf(fp, "%s %s %d", tree.uname, tree.pword, &tree.stt);
		insertEnd(list,tree);
	}  
	fclose(fp);
}
int checkAccount(singleList list, char ten[30], char mk[30]){
	// search all list to check username, pword is correct or not
	// if correct, return 1
	// else return 0
	list.cur = list.root;
	while(list.cur != NULL){
		if ((strcmp(list.cur->tree.uname, ten) == 0) && (strcmp(list.cur->tree.pword, mk) == 0)){
			return 1;
		}
		list.cur = list.cur->next;
	}
	return 0;
}
int checkBlock(singleList list, char ten[30]){

	list.cur = list.root;
	while(list.cur!=NULL){
		if (strcmp(list.cur->tree.uname, ten) == 0){
			if(list.cur->tree.stt == 1){
				return 1;
			}
			else{
				return 0;
			}
		}
		list.cur = list.cur->next;
	}
}
void blockData(singleList list,char ten[30]){
	
	list.cur = list.root;
	while(list.cur != NULL){
		if (strcmp(list.cur->tree.uname, ten) == 0){
			list.cur->tree.stt = 0;
			break;
		}
		list.cur = list.cur->next;
	}
	list.cur = list.root;

	FILE *fp;
	fp = fopen("account.txt","w");
	while(list.cur!=NULL){
		fprintf(fp,"%s %s %d\n",list.cur->tree.uname, list.cur->tree.pword, list.cur->tree.stt);
		list.cur = list.cur->next;
	}
	fclose(fp);
}
int main(int argc, char *argv[]){


	if (argc<2)
	{
		printf("Invalid Parameter\n");
		return 0;
	}

	FILE *fp;
	fp = fopen("account.txt","r");
	if (fp == NULL){
		printf("No file input\n");
		return 0;
	}

	singleList list;
	createSingleList(&list);
	elementtype tree;


	int PORT = atoi(argv[1]);
	int listenfd, connfd;
	struct sockaddr_in server;
	struct sockaddr_in client;
	pid_t pid;
	int sin_size;
	if ((listenfd = socket(AF_INET, SOCK_STREAM,0 )) == 0){
		perror("Socket Failed");
		exit(EXIT_FAILURE);
	}
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET; 
	server.sin_addr.s_addr = INADDR_ANY; 
	server.sin_port = htons( PORT ); 

	if(bind(listenfd, (struct sockaddr*)&server, sizeof(server))==-1){ 
		perror("\nError: ");
		return 0;
	}     

	if(listen(listenfd, 3) < 0){  
		perror("\nError: ");
		return 0;
	}
	signal(SIGCHLD, sig_chld);
	while(1){
		sin_size = sizeof(struct sockaddr_in);
		if ((connfd = accept(listenfd, (struct sockaddr *)&client, (socklen_t*)&sin_size))<0) { 
			perror("accept"); 
			exit(EXIT_FAILURE); 
		}
		pid = fork();
	
		char confirm[100];
		if (pid == 0){
			int i=0;
			for (i = 0;i<10;i++){
				getDatatoList(&list,tree);
				char asign_uname[1024] = {0};
				printf("You got a connection from %s\n", inet_ntoa(client.sin_addr));
				recv(connfd, asign_uname, sizeof(asign_uname), 0);
				printf("Server going to validate %s\n", asign_uname );
				if(searchData(list, asign_uname)==1){
					if (checkBlock(list,asign_uname) == 1){
						strcpy(confirm, DONE);
						send(connfd, confirm, strlen(confirm), 0);
						char asign_pword[1024] = {0};
						recv(connfd, asign_pword, sizeof(asign_pword), 0);
						printf("Check pass: %s\n", asign_pword );
						if (checkAccount(list,asign_uname,asign_pword) == 1){
							strcpy(confirm, DONE);
							send(connfd, confirm, strlen(confirm), 0);
						}
						else{
							strcpy(confirm, ERROR);
							send(connfd, confirm, strlen(confirm), 0);
							char asign_pword[1024] = {0};
							recv(connfd, asign_pword, sizeof(asign_pword), 0);
							printf("Check pass: %s\n", asign_pword );
							if (checkAccount(list,asign_uname,asign_pword) == 1){
								strcpy(confirm, DONE);
								send(connfd, confirm, strlen(confirm), 0);
							}
							else{
								strcpy(confirm, ERROR);
								send(connfd, confirm, strlen(confirm), 0);
								char asign_pword[1024] = {0};
								recv(connfd, asign_pword, sizeof(asign_pword), 0);
								printf("Check pass: %s\n", asign_pword );
								if (checkAccount(list,asign_uname,asign_pword) == 1){
									strcpy(confirm, DONE);
									send(connfd, confirm, strlen(confirm), 0);
								}
								else{
									strcpy(confirm, ERROR);
									send(connfd, confirm, strlen(confirm), 0);
									blockData(list,asign_uname);
								}
							}
						}
					}
					else{
						strcpy(confirm, BLOCKED);
						send(connfd, confirm, strlen(confirm), 0);
					}
				}
				else{
					strcpy(confirm, ERROR);
					send(connfd, confirm, strlen(confirm), 0);
				}
			}
			close(connfd);
		
		}
		close(connfd); 
	}
	
	return 0;
}