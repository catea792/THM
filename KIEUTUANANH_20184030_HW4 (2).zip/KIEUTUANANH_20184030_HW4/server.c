#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h> 
#include <arpa/inet.h>

#define SERV_PORTAL 1255
#define MAXLINE 255
#define SA struct sockaddr
#define MAX_CN 10

int sockfd, n,connfd;
socklen_t len;
char mesg[MAXLINE]; 
struct sockaddr_in servaddr, cliaddr;
socklen_t addrlen = sizeof(cliaddr);

int count = 0;
char account[30];


typedef struct{
    char user[15];
    char password[10];
    int stt;
    int checkLogin;
}Ch;

Ch *ch = NULL;

int readFile() {
    FILE *file = NULL;

    file = fopen("nguoidung.txt", "r");

    if (file == NULL) return -1;

    while (!feof(file)) {
        if (count == 0) ch = (Ch *) calloc(1, sizeof(Ch));
        else
            ch = (Ch *) realloc(ch,(count + 1) * sizeof(Ch));
        fscanf(file, "%s", ch[count].user);
        fscanf(file, "%s", ch[count].password);
        fscanf(file, "%d", &ch[count].stt);

        count++;
        }
    fclose(file);
    return 0;
}




int checkLogin(char * name){
    int i;
    for(i = 0; i < count ; i++){
        if(strcmp(name,ch[i].user) == 0){
            return 1;
        }
    }

    return 0;
}

int writeFile(){
    FILE *file = NULL;
    int n = 0;
    file = fopen("nguoidung.txt", "w");

    if (file == NULL) return -1;

    while (n < count) {
        if(n == count - 1) fprintf(file, "%10s %10s %d \n", ch[n].user,ch[n].password,ch[n].stt);
        else fprintf(file, "%10s %10s %d \n", ch[n].user,ch[n].password,ch[n].stt);
        n++;  
    }
    fclose(file);
    return 0;
}

int checkPassword(char * name,char * password){
    int i;
    for(i = 0; i < count ; i++){
        if(strcmp(name,ch[i].user) == 0){
            if(ch[i].stt == 1){
                if(strcmp(password,ch[i].password) == 0){
                    return 1;
                }else{
                    ch[i].checkLogin += 1;
                    if(ch[i].checkLogin >= 3){
                        ch[i].stt = 2;
                    }
                    writeFile();
                }
            }else{
                return -1;
            }
        }
    }

    return 0;
}

int changePassword(char *name,char* newPassword){
    int i;
    for(i = 0; i < count ; i++){
        if(strcmp(name,ch[i].user) == 0){
            strcpy(ch[i].password,newPassword);
            writeFile();
            return 1;
        }
    }  

    return 0;
}

int checkChar(char * messe){
    int i,check;
    char number[10] = {0};
    char letter[10] = {0};
    char ktdb[10] = {0};
    char noichuoi[20] = {0};
    int j=0,k=0,m=0;
    for(i = 0; i < strlen(messe); i++){
        check = messe[i] - '0';
        if((check >= 0 && check <= 9)){
            number[j] = messe[i];
            j++;
        }else if((check >= 49 && check <= 74) || (check >= 17 && check <= 42)){
            letter[k] = messe[i];
            k++;
        }else{
            ktdb[m] = messe[i];
            m++;
        }
    } 


    if(m == 0){
        strcat(noichuoi,number);
        strcat(noichuoi," ");
        strcat(noichuoi,letter);
        send(connfd, noichuoi, 100, 0);
        return 1;
    }else{
        send(connfd, "co ky tu dac biet", 100, 0);
        return 0;
    }
}

int main(int argc, char* argv[])
{    
    // socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("Created socket at port %d\n",atoi(argv[1]));
        exit(0);
    }
    else
        printf("Created socket successfully\n");
    bzero(&servaddr, sizeof(servaddr));
   
    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(atoi(argv[1]));
   
    // Binding newly created socket to given IP and verification
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        printf("socket bind failed...\n");
        exit(0);
    }
   
    // Now server is ready to listen and verification
    if ((listen(sockfd, 5)) != 0) {
        printf("Client failed\n");
        exit(0);
    }
    else
        printf("Watting for client\n");
    readFile();
    while(1){
        len = sizeof(cliaddr); 
    
        // Accept the data packet from client and verification
        connfd = accept(sockfd, (SA*)&cliaddr, &len);
        if (connfd < 0) {
            printf("Accept failed\n");
            exit(0);
        }
        else printf("Accept the client\n");
       
        for ( ; ; ) { 
            char user[15] = {0};
            char password[15] = {0};
            len = sizeof(cliaddr); 
            printf("Received mess :");
            n = recv(connfd, user, 10, 0); 
            puts(user);
            if(checkLogin(user) == 1){
                send(connfd, "done", 10, 0); 
                while (1)
                {
                    printf("Received mess : ");
                    n = recv(connfd, password, MAXLINE, 0); 
                    password[n] = 0;
                    puts(password);
                    int a = checkPassword(user,password);
                    if(a == 1){
                        send(connfd, "1", 100, 0); 
                        while(1){
                            printf("Received mess : ");
                            n = recv(connfd, mesg, MAXLINE, 0); 
                            mesg[n] = 0;
                            puts(mesg);
                            if(strcmp(mesg,"bye") == 0){
                                send(connfd, "out", 100, 0); 
                                break;
                            }else{
                                send(connfd, "done", 100, 0); 
                                printf("Received mess :");
                                n = recv(connfd, mesg, MAXLINE, 0); 
                                mesg[n] = 0;
                                puts(mesg);

                                if(checkChar(mesg) == 1){
                                    changePassword(user,mesg);
                                }
                            }
                        }
                        break;
                    }else if(a == 0){
                        send(connfd, "0", 100, 0); 
                    }else{
                        send(connfd, "-1", 100, 0);
                    }
                }          
            }else{
                send(connfd, "fail to login", 100, 0); 
            }
        }
    }

    free(ch);
    close(sockfd);
    
}
