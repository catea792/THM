#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> 
#include <stdbool.h>

#define MAXLINE 250
#define SA struct sockaddr

void Account(char * name){
    printf("input accountname : ");
    gets(name);
}

void Password(char * password){
    printf("input passpwd : ");
    gets(password);
}

int main(int argc, char* argv[])
{
    int n;
    int sockfd, connfd;
    struct sockaddr_in servaddr, cli;
    char  recvline[MAXLINE + 1];

   
    // socket create and varification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("Created failed...\n");
        exit(0);
    }
    else
        printf("Created successfully\n");
    bzero(&servaddr, sizeof(servaddr));
   
    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(atoi(argv[2]));
   
    // connect the client socket to server socket
    if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) {
        printf("Connection failed...\n");
        exit(0);
    }
    else
        printf("Connected successfully\n");
    printf("\n");

    while (1) { 
        char name[15];
        char matkhau[15];
        bool check = false;
        Account(name);
        send(sockfd, name, strlen(name), 0);
        n = recv(sockfd, recvline, MAXLINE, 0);
        recvline[n] = 0;   
        printf("From Server: %s\n",recvline);
        if(strcmp(recvline,"done") == 0){
            check = true;
            while (check)
            {
                Password(matkhau);
                send(sockfd, matkhau, strlen(matkhau), 0);
                n = recv(sockfd, recvline, MAXLINE, 0);
                recvline[n] = 0;   
                printf("Server: %s\n",recvline);

                if(strcmp(recvline,"1") == 0){
                    printf("login successful\n");
                    while (1)
                    {
                        char mess[MAXLINE];
                        printf("Client : "); gets(mess);
                        if(strcmp(mess,"bye") == 0){
                            send(sockfd, "bye", 100, 0);
                            n = recv(sockfd, recvline, MAXLINE, 0);
                            recvline[n] = 0;  
                            printf("Server: %s\n",recvline);
                            break;
                        }else if(strcmp(mess,"changepwd") == 0){
                            char newPassword[10];
                            send(sockfd, "changepwd", 100, 0);
                            n = recv(sockfd, recvline, MAXLINE, 0);
                            recvline[n] = 0;  
                            printf("From Server: %s\n",recvline);
                            printf("input new password : "); gets(newPassword);
                            send(sockfd,newPassword, strlen(newPassword), 0);
                            n = recv(sockfd, recvline, MAXLINE, 0);
                            recvline[n] = 0;  
                            printf("Server: %s\n",recvline);
                        }else{
                            continue;
                        }
                    }                  
                    
                    check = false;
                }else if(strcmp(recvline,"0") == 0){
                    printf("password incorrect\n");
                }else{
                    printf("account is blocked\n");
                
                }
            }     
        }
    } 
}
